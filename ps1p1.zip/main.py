#comment input
n1 = float(input("Enter a number"))
n2 = float(input("Enter another number"))

#process phase
d = n1 - n2
s = n1 + n2
p = n1 * n2

# output
print ("The sum is ", s)
print ("The difference ", d)
print ("The product is ", p)