# input phase
lname = input("Enter student last name")
score1 = float(input("Enter exam score 1"))
score2 = float(input("Enter exam score 2"))

# process phase

avg = (score1 + score2) / 2

# output phase
print(lname, " has average of ", avg)



