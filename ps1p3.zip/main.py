# input
milest = float(input("Enter miles travelled"))
gallons = float(input("Enter gallons used"))

# process phase
mpg = milest/gallons

# output
print("Miles per gallon achieved ", mpg)
